var fs = require('fs'),
url = require('url'),
path = require('path'),
utils_obj=require('./utils.js'),
user = require('./user_logins.js');
var validExtensions = {
	"" : "text/html",
	".html" : "text/html",
	".js": "application/javascript",
	".zip": "application/zip",
	".exe": "application/text",
	".xls": "application/text",
	".css": "text/css",
	".txt": "text/plain",
	".jpeg": "image/jpeg",
	".JPEG": "image/JPEG",
	".jpg": "image/jpg",
	".JPG": "image/JPG",
	".gif": "image/gif",
	".GIF": "image/GIF",
	".png": "image/png",
	".swf": "application/x-shockwave-flash",
	".PNG": "image/PNG",
	".pdf": "application/pdf",
	".ico": "image/vnd.microsoft.icon",
	".svg"  : "image/svg+xml",
	".ttf"   : "application/x-font-truetype", //"application/x-font-ttf", //
	".otf"   : "apllication/font-sfnt", //"apllication/font-sfnt" , "application/x-font-opentype"
	".woff"  : "application/font-woff",
	".woff2" : "application/font-woff2",
	".eot"   :  "application/vnd.ms-fontobject", //"application/vnd.ms-fontobject",
	".sfnt"  : "application/font-sfnt",
	".map" : "application/octet-stream",
	".csv" : "application/javascript",
	".json":"application/json"
};
var sessionApicalls = [
					"/login",
					"/user_signup",
					"/getConfig",
					"/getUsersOverview",
					"/logout",
					"/triggerIDLPull",
					"/triggerMLPull",
					"/getFileBrowser",
					"/getPlatformSources",
					"/getUserIDLList",
					"/getUserMlList",
					"/getExternelAPI",
					"/getUserAdlList",
					"/getUserHdReportsList",
					"/getApiHtmlinfo"
					]
var restApicalls=[
				"/api/weather_forecast",
				"/api/weather_forecast_json",
				"/api/weather_historical",
				"/api/weather_historical_json",
				"/api/db_link_hiddime_req"
				]
exports.route_functions = function route_functions(req,res,localPath){
	var urlString = url.parse(req.url, true);
	var pathUrl = urlString.pathname;
    if(	pathUrl == "/")
  	{
		var indexHtml = "";
		console.log("76")
		indexHtml = fs.readFileSync(localPath+'home.html','utf8');
		indexHtml = indexHtml.replace("//{{signin_singup}}","signin_singup_display();");
		indexHtml = indexHtml.replace("//enableStandalone();","enableStandalone();");
		res.writeHead(200, {'Content-Type': "text/html"});
		res.write(indexHtml);
		res.end();
    }
    else if(restApicalls.indexOf(pathUrl) > -1){
    	restApiRequest(req,res,localPath,urlString);
    }
    else{
		userApiRequest(req, res, localPath, urlString);
	}
	function userApiRequest(req, res, localPath, urlString){
		switch( pathUrl )
		{
			case "/login":
				user.login_user(req,res,localPath);
				break;
			case "/user_signup":
				user.user_signup(req,res,localPath);
				break;
			case "/getUsersInfo":
				user.getUsersInfo(urlString,req,res);
				break;
			case "/logout":
				user.logout(req,res,localPath);
				break;
			case "/createUser":
				user.createUser(urlString,req,res);
				break;
			case "/deleteUser":
				user.deleteUser(urlString,req,res);
				break;
			default :
				var fileExt = path.extname(pathUrl);
				var mimeType="text/html",filePath="";
				if(pathUrl=="/"){
					filePath=localPath + "admin_html.html";
					mimeType=validExtensions[""];
				}
				else{
					filePath = localPath + pathUrl;
					mimeType = validExtensions[fileExt];
				}
				utils_obj.loadContent(filePath,mimeType,res);
		}
	};
	function restApiRequest(req,res,localPath,urlString){
		switch(pathUrl)
		{
			case "/api/weather_forecast":
				external_api.forecastApiCall(req,res,urlString);
				break;
			case "/api/weather_forecast_json":
				external_api.forecastApiCall(req,res,urlString);
				break;
			case "/api/weather_historical":
				external_api.historicalApicall(req,res,urlString);
				break;
			case "/api/weather_historical_json":
				external_api.historicalApicall(req,res,urlString);
				break;
			case "/api/db_link_hiddime_req":
				external_api.writeHiddimeAPICall(req,res,urlString);
				break;
			default:
    			return 'not yet configured any api';
		}
	}
}
