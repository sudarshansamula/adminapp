"use strict";
var fs = require('fs'),
	url = require('url'),
	os = require('os'),
	path = require('path'),
	request = require('request'),
	moment = require('moment');
var localPath = __dirname;
var _this = module.exports = {
	loadContent:function (filePath, mimeType, res){//Load content to the browser
			if(filePath!=""){
				if(	mimeType == "image/jpg" ||
					mimeType == "image/jpeg" ||
					mimeType == "image/JPEG" ||
					mimeType == "image/JPG" ||
					mimeType == "image/gif" ||
					mimeType == "image/GIF" ||
					mimeType == "image/png" ||
					mimeType == "image/PNG"||
					mimeType == "image/vnd.microsoft.icon" ||
					mimeType == "application/pdf" ||
					mimeType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
					mimeType == "image/svg+xml" ||
					mimeType == "application/x-font-truetype" ||
					mimeType == "apllication/font-sfnt" ||
					mimeType == "application/font-woff" ||
					mimeType == "application/font-woff2" ||
					mimeType ==  "application/vnd.ms-fontobject" ||
					mimeType == "application/font-sfnt"	||
					mimeType == "application/octet-stream")
				{
						//console.log( "LOG : (binary) Loading File Path - "+filePath);

						var img = fs.readFileSync( filePath );
						res.writeHead(200, {'Content-Type': mimeType});
						res.write(img,'binary');
						res.end();
				}
				else{

					fs.readFile(filePath, 'utf8', function (err, data) {
						if (err) {
							console.log("error at loading",filePath,mimeType)
							let localPath = path.dirname(require.main.filename);
							let info_str = fs.readFileSync(localPath+"/public/info.html", "utf8");
							info_str = info_str.replace("{{message}}", "Error loading "+filePath)
							res.writeHead(200, {'Content-Type': "text/html"});
							res.end(info_str);
							return;
						}
						//console.log( "LOG : (utf8) Loading File Path - "+filePath);
						res.writeHead(200, {'Content-Type': mimeType});
						res.write(data);
						res.end();
					});
				}
		}else{
			res.writeHead(200, {'Content-Type': mimeType});
			res.end("No File Path Found");
			return;
		}
	},
	sendJSON : function(res, jsonData)
	{
		res.writeHead(200, {'Content-Type': "text/javascript"});
		res.end( JSON.stringify(jsonData) );
	}
};
