var fs = require('fs'),
config_path = __dirname;
qs = require('querystring'),
utils_obj = require('./utils.js'),
sql_obj=require('./sql.js');
var _this = module.exports = {
  login_user : function(req, res, localPath){
    try{
      console.log(" LOG - Login Request");
      var body = '';
          req.on('data',chunk=>{
            body +=chunk;
          });
          req.on('end',()=>{
            console.log("user login ****************",req.session)
              var data = qs.parse(body);
              _this.valiDateExistingorNOt(req,res,localPath,data)
          });
    }
    catch(exce){
      console.log(exce);
       _this.redirectTologin(res,localPath)
       utils_obj.log_err_file(exce, null, req);
    }


  },
  logout : function(req,res,localPath)
  { 
    console.log("reading",localPath)
    var indexHtml = fs.readFileSync(localPath+'home.html','utf8');
    indexHtml = indexHtml.replace("//enableStandalone();","enableStandalone();");
    req.session={};
    console.log(req.session)
    _this.send_json(res,indexHtml);
  },
  valiDateExistingorNOt:function(req,res,localPath,data){
    var email = data.email;
    var password = data.password;
    var indexHtml,rows_arr=[],row_Obj;
    var sel_qry="select * from user_info where email="+JSON.stringify(email);
    var conn=sql_obj.getDB();
    conn.query(sel_qry,(err,sel_rows)=>{
      var error_arry=["ER_ACCESS_DENIED_ERROR","ER_NOT_SUPPORTED_AUTH_MODE"];
      if(err != null && err.code && err.code == "ER_BAD_FIELD_ERROR"){
        _this.redirectTologin(res,localPath)
        sql_obj.clsDB(conn);
        return;
      }
      if(err != null && error_arry.indexOf(err.code) >-1 ){
        _this.redirectTologin(res,localPath)
        sql_obj.clsDB(conn);
        return;
      }
      if(sel_rows.length > 0){
        if(password != sel_rows[0].password){
          indexHtml = fs.readFileSync(localPath+'home.html','utf8');
          indexHtml = indexHtml.replace("//{{signin_singup}}","show_error('Incorrect Password.');");
          indexHtml = indexHtml.replace("//enableStandalone();","enableStandalone();");
        }else{
          req.session={};
          var isAdmin=false;
          if(sel_rows[0].user_type == "admin"){
            isAdmin=true;
          }
          req.session.isAdmin=isAdmin;
          indexHtml = fs.readFileSync(localPath+'admin.html','utf8');
        }
      }else{
        indexHtml = fs.readFileSync(localPath+'home.html','utf8');
        indexHtml = indexHtml.replace("//{{signin_singup}}","show_error('Incorrect email or password.');");
        indexHtml = indexHtml.replace("//enableStandalone();","enableStandalone();");
      }
      _this.send_json(res,indexHtml)
    });
  },
  send_json:function(res,indexHtml){
    res.writeHead(200, {'Content-Type': "text/html"});
    res.write(indexHtml);
    res.end();
    return;
  },
  redirectTologin:function(res,localPath){
    var indexHtml = fs.readFileSync(localPath+'home.html','utf8');
    indexHtml = indexHtml.replace("//{{signin_singup}}","show_error('Incorrect email or password.');");
    indexHtml = indexHtml.replace("//enableStandalone();","enableStandalone();");
    _this.send_json(res,indexHtml);
  },
  getUsersInfo : function(urlString,req, res){
    let connection = sql_obj.getDB();
    let query = "select *from user_info where user_type ='user'";
    if(req.session.isAdmin){
      query = "select *from user_info";
    }
    var res_obj = {};
    connection.query(query,function(err,uRows){
      sql_obj.clsDB(connection);
      if(err){
        res_obj = {"message":"failure","data":"Sorry, unable process your request"};
      }else{
        res_obj = {"message":"success","data":uRows,"isAdmin":req.session.isAdmin}
      }
      utils_obj.sendJSON(res,res_obj)
    });
  },
  createUser:function(urlString,req,res){
    let connection = sql_obj.getDB();
    let insertObj=JSON.parse(urlString.query["insertInfo"]);
    var email=insertObj.email;
    var name=insertObj.name;
    var password=insertObj.password;
    var user_type=insertObj.user_type;
    var feed_back=insertObj.feed_back;
    let insert_query ="insert into user_info(email,password,name,user_type,feed_back) values(?,?,?,?,?)";
    var res_obj = {},valuesArr=[email,password,name,user_type,feed_back];
    connection.query(insert_query,valuesArr,function(err,insrows){
      sql_obj.clsDB(connection);
      if(err){
        res_obj = {"message":"failure","data":"Sorry, unable process your request"};
      }else{
        res_obj = {"message":"success","data":"Create User Successfully"}
      }
      utils_obj.sendJSON(res,res_obj);
    });
  },
  deleteUser:function(urlString,req,res){
    let connection = sql_obj.getDB();
    var dltID=urlString.query["id"];
    var dltquery="delete from user_info where id="+dltID;
    connection.query(dltquery,function(err,dltrows){
      sql_obj.clsDB(connection);
      if(err){
        res_obj = {"message":"failure","data":"Sorry, unable process your request"};
      }else{
        res_obj = {"message":"success","data":"Deleted User Successfully"};
      }
      utils_obj.sendJSON(res,res_obj);
    });
  }

};
