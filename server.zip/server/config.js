var _this = module.exports = 
{
	"mysql_ds": { 
		"host":"localhost",
		"user":"root",
		"port" : "3306",
		"password":"",
		"database":"NetElixir",
		"insecureAuth":true,
		"dateStrings": "date",
		"supportBigNumbers": true
	}
};

