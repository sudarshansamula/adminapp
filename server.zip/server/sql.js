"use strict";
var mysql = require('mysql'),
	config = require("./config.js");

var _this = module.exports = {
	getDB:function(){
		var conn;
		/*if(isDatasource == true){
			var userDbConfig = JSON.parse(JSON.stringify(config.mysql_ds));
			userDbConfig.database = userDbConfig.database+"_"+user_id;
			if(user_id)
				conn = mysql.createConnection(userDbConfig);
			else
				conn = mysql.createConnection(config.mysql_ds);
		}
		else*/
			conn = mysql.createConnection(config.mysql_ds);
		return conn;
	},
	clsDB:function(conn){
		conn.end();
	},
	getRemoteCon(){
		var conn;
		conn = mysql.createConnection(config.remote_mysql_ds);
		return conn; 
	},
	getmultipleDB:function(){
		var userDbConfig = JSON.parse(JSON.stringify(config.mysql_ds));
	    userDbConfig.multipleStatements = true;
		connection = mysql.createConnection(userDbConfig);
		return connection;
	}
}
